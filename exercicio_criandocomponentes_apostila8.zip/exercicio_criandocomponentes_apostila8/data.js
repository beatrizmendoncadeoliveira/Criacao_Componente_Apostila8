const data={
  fotos: [
    {
      picId:1,
      pic:'https://i.imgur.com/bTIbBnY.jpg',
      picLegend:'CORRIDA',
      picLegend2:' 440m 300Kcal  43kg',
      picLegend3:'   HOJE          ONTEM'
    },
    {
       picId:2,
       pic:'https://i.imgur.com/bTIbBnY.jpg',
       picLegend: 'BICICLETA ',
       picLegend2:'400Kcal 30m 50kg',
       picLegend3:'  HOJE          ONTEM'
 
    },
     {
       picId:3,
       pic:'https://i.imgur.com/bTIbBnY.jpg',
       picLegend: 'YOGA ',
       picLegend2:'400Kcal 30m 50kg',
       picLegend3:'  HOJE          ONTEM'
     },
     {
       picId:4,
      pic:'https://i.imgur.com/bTIbBnY.jpg',
      picLegend:'CORRIDA',
      picLegend2:' 440m 300Kcal  43kg',
      picLegend3:'   HOJE          ONTEM'
     },
     {
     picId:5,
       pic:'https://i.imgur.com/bTIbBnY.jpg',
       picLegend: 'BICICLETA ',
       picLegend2:'400Kcal 30m 50kg',
       picLegend3:'  HOJE          ONTEM'
     },
     {
       picId:6,
       pic:'https://i.imgur.com/bTIbBnY.jpg',
       picLegend: 'YOGA ',
       picLegend2:'400Kcal 30m 50kg',
       picLegend3:'  HOJE          ONTEM'
     },
     {
       picId:7,
       pic:'https://i.imgur.com/bTIbBnY.jpg',
      picLegend:'CORRIDA',
      picLegend2:' 440m 300Kcal  43kg',
      picLegend3:'   HOJE          ONTEM'
     }
  ]
};

export default data;
