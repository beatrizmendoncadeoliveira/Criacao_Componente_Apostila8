import {StyleSheet} from 'react-native';

const styles=StyleSheet.create({
  container:{
    flexDirection:'row',
  },
  imagem:{
    width:58,
    height:58
  },
  titulo:{
    fontSize:40,
    marginLeft:10
  },
  imagem2:{
    marginLeft:30
  },
})

export default styles;