import React from 'react';
import{View, Image, Text} from 'react-native';
import styles from './estilo'

export default class Cabecalho extends React.Component{
  render(){
    return(
  <>
  <View style={styles.container}>
    <Image style={styles.imagem}
            source={this.props.src} />
           
    <Text style={styles.titulo}>MEU PERFIL</Text>
    <Image style={styles.imagem2}
            source={this.props.src2}/>
           
    </View>
</>
    );
  }


}