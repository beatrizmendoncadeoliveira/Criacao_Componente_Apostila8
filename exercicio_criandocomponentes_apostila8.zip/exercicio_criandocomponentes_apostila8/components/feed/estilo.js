import {StyleSheet} from 'react-native';

const styles=StyleSheet.create({
  container2:{
     flexDirection:'row',
    padding:10,
  },
   
imagem3:{
    width:80,
    height:80,
    borderRadius:50,
  },
  texto:{
    fontWeight:'bolder',
    fontFamily:'Arial',
    fontSize:30,
    marginLeft:12
  },
});

export default styles;