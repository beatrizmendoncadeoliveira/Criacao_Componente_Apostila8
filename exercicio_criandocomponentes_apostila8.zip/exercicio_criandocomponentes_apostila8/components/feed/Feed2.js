import React from 'react';
import{View, Image, Text} from 'react-native';
import styles from './estilo'

export default class Feed extends React.Component{
render(){
  return(
<>

<View style={styles.container2}>
    <Image style={styles.imagem3}
            source={this.props.src}/>  
    <View>
    <Text style={styles.texto}>{this.props.legenda1}</Text> 
    <Text>{this.props.legenda2}</Text> 
    <Text>{this.props.legenda3}</Text> 
    </View>
    </View>
</>
);
}}