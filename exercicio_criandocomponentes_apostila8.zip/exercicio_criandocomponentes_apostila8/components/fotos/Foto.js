import React from  'react';
import{View, Image} from 'react-native';
import styles from './estilo'



export default class Foto extends React.Component{
  render(){
    return(
      <>

      <View style={styles.container2}>
    <Image style={styles.icone}
            source={this.props.src} />
    
    <Image style={styles.icone}
          source={this.props.src2}/>
     
     <Image style={styles.icone}
     source={this.props.src3}/>
 
     <Image style={styles.icone}
            source={this.props.src4}/>
     
    </View>
      </>
    );

  }
}