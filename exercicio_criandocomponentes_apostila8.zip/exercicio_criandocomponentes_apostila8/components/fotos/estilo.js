import{StyleSheet} from 'react-native';


const styles=StyleSheet.create({
  container2:{
     flexDirection:'row',
    padding:10,
  },
   
  icone:{
    width:80,
    height:80
  }
})

export default styles;
