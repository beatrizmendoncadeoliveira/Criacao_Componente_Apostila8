import React from 'react';
import {FlatList} from 'react-native';
import data from './data'
import Post from './Post'




export default class App extends React.Component{
  render(){
    const fotos=data.fotos;
  return (
    
    <FlatList
    keyExtractor={item => item.picId.toString()}
    data={data.fotos}
    renderItem={ ({item}) =>
   <Post foto={item} />

    
    } />
  
    
   
  );
}}
