import React from 'react';
import Cabecalho from './components/cabecalho/Cabecalho'
import Foto from './components/fotos/Foto'
import Feed from './components/feed/Feed'
import Feed2 from './components/feed/Feed2'

export default class Post extends React.Component{
  render(){
     const foto=this.props.foto;
    return(
      <>
    
  <Feed src={foto.pic} 
  legenda1={foto.picLegend}
  legenda2={foto.picLegend2}
  legenda3={foto.picLegend3}/>
  
 



      </>
    );
  }
}